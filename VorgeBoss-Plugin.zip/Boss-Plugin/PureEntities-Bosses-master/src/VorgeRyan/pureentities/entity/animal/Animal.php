<?php

namespace vorge\pureentities\entity\animal;

use pocketmine\entity\Ageable;

interface Animal extends Ageable{

}