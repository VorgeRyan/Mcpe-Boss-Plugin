<?php

use pocketmine\scheduler\Task;

class AutoSpawnTask extends Task{

    public function onRun($currentTick){
        //TODO
    }

}